import { useRef, useState } from "react";
import { Platform, Pressable, StyleSheet, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { ExpoSpeechRecognitionModule, ExpoWebSpeechRecognition } from "expo-speech-recognition";
import { colors } from "../lib/theme";
import { useTourHighlight } from "../lib/tour/MobileTourProvider";

export function AskAgentControl({
  accent = "#ffad45",
  accentInk = "#1a0c00",
  onCommand,
  tourTargetId,
}: {
  accent?: string;
  accentInk?: string;
  onCommand: (text: string) => Promise<void> | void;
  /** Anchor id for the guided app tour (see lib/tour/steps.ts) — spotlighted when this step is active. */
  tourTargetId?: string;
}) {
  const { highlightStyle } = useTourHighlight(tourTargetId);
  const [inputOpen, setInputOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const [listening, setListening] = useState(false);
  const [busy, setBusy] = useState(false);
  const holdTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const longPressRef = useRef(false);

  async function submit(text: string) {
    const command = text.trim();
    if (!command || busy) return;
    setBusy(true);
    setDraft("");
    setInputOpen(false);
    try {
      await onCommand(command);
    } finally {
      setBusy(false);
    }
  }

  // Shared between the browser's native SpeechRecognition (web) and the
  // expo-speech-recognition polyfill (native) — both expose the same
  // start/onstart/onresult/onerror/onend surface, so only construction differs.
  function startSpeechRecognition(recognition: any) {
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onstart = () => setListening(true);
    recognition.onerror = () => setListening(false);
    recognition.onend = () => setListening(false);
    recognition.onresult = (event: any) => {
      const text = Array.from(event.results ?? [])
        .map((result: any) => result?.[0]?.transcript ?? "")
        .join(" ")
        .trim();
      void submit(text);
    };
    recognition.start();
  }

  async function startVoice() {
    setInputOpen(false);
    if (Platform.OS === "web") {
      if (typeof window === "undefined") {
        setInputOpen(true);
        return;
      }
      const Ctor = (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition;
      if (!Ctor) {
        setInputOpen(true);
        return;
      }
      startSpeechRecognition(new Ctor());
      return;
    }

    const permission = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    if (!permission.granted) {
      setInputOpen(true);
      return;
    }
    startSpeechRecognition(new ExpoWebSpeechRecognition());
  }

  function openInput() {
    longPressRef.current = true;
    if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
    holdTimerRef.current = null;
    setInputOpen(true);
  }

  function pressIn() {
    longPressRef.current = false;
    if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
    holdTimerRef.current = setTimeout(openInput, 2000);
  }

  function pressOut() {
    if (holdTimerRef.current) clearTimeout(holdTimerRef.current);
    holdTimerRef.current = null;
  }

  function press() {
    if (longPressRef.current) {
      longPressRef.current = false;
      return;
    }
    void startVoice();
  }

  return (
    <>
      {!inputOpen ? (
        <Pressable
          onPress={press}
          onPressIn={pressIn}
          onPressOut={pressOut}
          onLongPress={openInput}
          delayLongPress={2000}
          disabled={busy}
          style={({ pressed }) => [
            styles.fab,
            { backgroundColor: accent },
            listening ? styles.fabActive : null,
            pressed ? { transform: [{ scale: 0.98 }] } : null,
            highlightStyle ? [highlightStyle, { borderRadius: 28 }] : null,
          ]}
          accessibilityRole="button"
          accessibilityLabel="Ask agent"
          {...(Platform.OS === "web" ? ({ onContextMenu: (event: { preventDefault?: () => void }) => event.preventDefault?.() } as any) : {})}
        >
          <Ionicons name="sparkles-outline" size={22} color={listening ? accent : accentInk} />
        </Pressable>
      ) : null}
      {inputOpen ? (
        <View style={styles.inputOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setInputOpen(false)} />
          <TextInput
            autoFocus
            value={draft}
            onChangeText={setDraft}
            editable={!busy}
            placeholder="Ask agent"
            placeholderTextColor={colors.inkFaint}
            style={styles.input}
            returnKeyType="send"
            blurOnSubmit
            onSubmitEditing={() => submit(draft)}
            onBlur={() => submit(draft)}
            onKeyPress={(event) => {
              if (event.nativeEvent.key === "Enter") void submit(draft);
            }}
          />
        </View>
      ) : null}
    </>
  );
}

const styles = StyleSheet.create({
  fab: {
    position: "absolute",
    right: 16,
    bottom: 84,
    zIndex: 900,
    elevation: 20,
    height: 56,
    width: 56,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 28,
    shadowColor: "#0f172a",
    shadowOpacity: 0.18,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
  },
  fabActive: { backgroundColor: colors.surfaceRaised, borderWidth: 1, borderColor: colors.line },
  inputOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 950,
    elevation: 30,
    justifyContent: "flex-end",
    paddingHorizontal: 18,
    paddingBottom: 92,
  },
  input: {
    height: 56,
    borderRadius: 28,
    borderWidth: 1,
    borderColor: colors.line,
    backgroundColor: colors.surfaceRaised,
    paddingHorizontal: 20,
    color: colors.ink,
    fontSize: 15,
    shadowColor: "#0f172a",
    shadowOpacity: 0.12,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 10 },
    elevation: 10,
  },
});
